package com.travelsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelBookingSystemApplication.class, args);
	}

}
